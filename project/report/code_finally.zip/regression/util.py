import numpy as np
import pandas as pd

#tag赋予不同的数值进行处理，生成5个新的属性，总共11个属性，dfnew列数为12
def wordInTag(word, tag):
    '''判断tag中是否有单词word，有则返回对应的tag，没有则返回false'''
    for t in tag:
        if word in t:
            return t
    return False

def preprocess(df):
    '''数据预处理，主要是tag的预处理'''
     
    #属性对应的值
    attr = {'Solo traveler':4,'Couple':1,'Family with young children':2,'Group':3}
    tagTypes = {'trip':{},'room':{},'stay':{}}
    
    #将tag处理成属性值，扩展到df中
    tags = df['Tags'].values
    for i,tag in enumerate(tags):
        tag = tag.strip('[] ').split(',')
        a = []
        for t in tag:
            t = t.strip("' ")
            a.append(t)
        tags[i] = a
    
    #处理成五维的属性
    tag_numbers = []
    for tag in tags:
        tag_numbers.append([])

        fpet = wordInTag('pet',tag)
        ftrip = wordInTag('trip',tag)
        froom = wordInTag('oom',tag) 
        fstay = wordInTag('Stayed',tag)

        if fpet:
            tag_numbers[-1].append(1)
        else:
            tag_numbers[-1].append(0)

        if ftrip:
            if ftrip not in tagTypes['trip']:
                tagTypes['trip'][ftrip] = tagTypes['trip'].get(ftrip, len(tagTypes['trip'])+1) 
            tag_numbers[-1].append(tagTypes['trip'][ftrip])
        else:
            tag_numbers[-1].append(0)

        if froom:
            if froom not in tagTypes['room']:
                tagTypes['room'][froom] = tagTypes['room'].get(froom, len(tagTypes['room'])+1) 
            tag_numbers[-1].append(tagTypes['room'][froom])
        else:
            tag_numbers[-1].append(0)

        if fstay:
            if fstay not in tagTypes['stay']:
                tagTypes['stay'][fstay] = tagTypes['stay'].get(fstay, len(tagTypes['stay'])+1) 
            tag_numbers[-1].append(tagTypes['stay'][fstay])
        else:
            tag_numbers[-1].append(0)

        fnum = False
        for attrx in attr:
            if wordInTag(attrx,tag):
                fnum = True
                break
        if fnum:
            tag_numbers[-1].append(attr[attrx])
        else:
            tag_numbers[-1].append(0)

    #将五维的tag加入df属性值中
    tagattr = np.array(tag_numbers)
    dfattr = pd.DataFrame({'pet':tagattr[:,0],
                          'trip':tagattr[:,1],
                          'room':tagattr[:,2],
                          'stay':tagattr[:,3],
                          'num':tagattr[:,4]})
    dfnew = pd.concat([df,dfattr],axis=1)
    
    return dfnew
