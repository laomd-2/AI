# coding=utf-8
from decision_tree import RegressionTree
from sklearn.model_selection import KFold, train_test_split
import numpy as np
import progressbar

class GBDTRegressor:
    """ Uses a collection of CART models that trains on predicting the gradient
        of the loss function.

        Parameters:
        -----------
        # n_estimators: int
            至多使用的树的数量
            The number of regression trees that at most are used.
        learning_rate: float
            残差的学习率
            The shrinkage step length that will be taken to correct the residual error
        min_samples: int
            每棵子树的节点的最小数目（小于后不继续切割）
            The minimum number of samples needed to make a split when building a tree.
        min_impurity: float
            每颗子树的最小纯度（小于后不继续切割）
            The minimum impurity required to split the tree further.
        max_depth: int
            每颗子树的最大层数（大于后不继续切割）
            The maximum depth of a tree.
        loss_func:
            残差计算公式
            function to calculate residual error
        """

    def __init__(self, n_estimators=200, learning_rate=0.5, min_samples=2,
                 min_impurity=1e-7, max_depth=4):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.min_samples = min_samples
        self.min_impurity = min_impurity
        self.max_depth = max_depth
        self.weighted_trees = []
        bar_widgets = [
            'Training: ', progressbar.Percentage(), ' ', progressbar.Bar(marker="-", left="[", right="]"),
            ' ', progressbar.ETA()
        ]
        self.bar = progressbar.ProgressBar(widgets=bar_widgets)


    # with_bar 控制是否显示进度条
    def fit(self, X, y, with_bar=False):
        zeros = np.zeros_like(y)
        # 当前已经使用的CART模型的数量
        n_estimators = 0
        residual_error = y.copy()

        # 至多使用self.n_estimators棵树

        it_est = None
        if with_bar:
            it_est = self.bar(range(1, self.n_estimators))
        else:
            it_est = range(1, self.n_estimators)

        for i in it_est:
        # while n_estimators < self.n_estimators:
            self.weighted_trees.append(RegressionTree(min_samples=self.min_samples,
                                                      min_impurity=self.min_impurity,
                                                      max_depth=self.max_depth))
            # n_estimators += 1
            # GDBT模型每棵树训练的label实际上残差
            # 残差Ri = y - sum(y_predict_i), i=1,2,3,...,n_estimators
            self.weighted_trees[-1].fit(X, residual_error)
            y_pred = self.weighted_trees[-1].predict(X)
            # print(y_pred.shape)
            # 对于残差学习出来的结果，只累加一小部分（learning_rate）逐步逼近目标
            # 即每次只纠正一点点错误而不是一步纠正，有效避免过拟合
            residual_error -= self.learning_rate * y_pred
            # 残差为0，说明模型已经拟合y
            if (residual_error == zeros).all():
                break

    def predict(self, X):
        y_pred_res = np.zeros((X.shape[0], ))
        # 由于训练的时候只取训练结果的一小部分，预测的时候也要乘learning_rate
        for y_pred in map(lambda t: self.learning_rate * t.predict(X), self.weighted_trees):
            y_pred_res += y_pred
        return y_pred_res


    def print_tree(self):
        '''打印所有的树'''
        for t in self.weighted_trees:
            t.print_tree(t.root)
            print('')


class RandomForest:
    def __init__(self, min_samples=2, min_impurity=1e-7):
        self.min_samples = min_samples
        self.min_impurity = min_impurity
        self.tree = []  #存放每棵树

    def fit(self, X, y, tree_num=10, feat_size=4, max_depth=3):
        '''
            树的数目 tree_num
            最大树深度max_depth
            特征集大小，每次随机取的特征数  feat_size
        '''
        n_samples, n_features = np.shape(X)
        for _treeCnt in range(tree_num):
            #有放回抽样数据集
            slicex = np.array(range(n_samples))
            slicex = np.random.choice(slicex,size=n_samples,replace = True)
            _X = X[slicex,:]
            _y = y[slicex]
            #抽样特征
            feature_use = np.random.choice(range(0,n_features),replace=False,size = feat_size)
            feature_use = np.concatenate(([1],feature_use))

            #模型拟合
            model = RegressionTree(max_depth=max_depth)
            model.fit(_X, _y,feature_use)
            self.tree.append(model)    #将多个决策树加到model_gather中

    def predict(self, X):
        y_pred = np.zeros(len(X))
        for model in self.tree:
            y_pred = model.predict(X) + y_pred #直接进行验证
        return y_pred/len(self.tree)



def model_valid(x_train, x_valid,y_train, y_valid, \
        param = ['GBDT', 100, 3, 0.2]):
    if param[0] == 'GBDT':
        model = GBDTRegressor(n_estimators=param[1], max_depth=param[2], learning_rate=param[3])
        model.fit(x_train, y_train)
        y_pred = model.predict(x_valid)
        return np.corrcoef(y_valid, y_pred)[0,1]
    elif param[0] == 'RF':
        model = RandomForest()
        model.fit(x_train, y_train, tree_num=param[1], max_depth=param[2], feat_size=param[3])
        y_pred = model.predict(x_valid)
        return np.corrcoef(y_valid, y_pred)[0,1]


def cross_val(x, y, param = ['GBDT', 100, 3, 0.2]):
    '''
    此函数用于交叉验证
    input:
        x, y: 训练集数据
        param: list[model_name, model_param]  
            ['GBDT', n_estimators, max_depth, learning_rate]
            ['RF', tree_num, max_depth, feat_size]
    return:
        corrcoef
    '''
    sss = KFold(n_splits=5, shuffle = True, random_state=4)
    corr = []
    for train_index, valid_index in sss.split(x,y):
        x_train, x_valid = x[train_index], x[valid_index]
        y_train, y_valid = y[train_index], y[valid_index]
        corr.append(model_valid(x_train, x_valid,y_train, y_valid,param))
    return np.mean(corr)