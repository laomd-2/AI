import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from frame import GBDTRegressor, RandomForest, cross_val
from util import preprocess

#df.shape=(80000, 8), dftest.shape=(30000, 7)
df = pd.read_excel('data/回归/train.xlsx')
dftest = pd.read_excel('data/回归/testStudent.xlsx')

dfnew = preprocess(df)
dftestnew = preprocess(dftest)
train_labels = dfnew.loc[:,'Reviewer_Score']
del dfnew['Reviewer_Score']
del dfnew['Tags']
train_data = dfnew.iloc[:]
del dftestnew['Tags']
test_data = dftestnew.iloc[:]

# train_label.shape=(80000,1)
# train_data.shape=(80000,11)
# test_data.shape=(30000, 11)

#回归0.6623 ['GBDT', 140, 3, 0.2]
model_gbdt = GBDTRegressor(n_estimators=140,learning_rate=0.2,max_depth=3)
model_gbdt.fit(train_data.values, train_labels.values, with_bar=True)
y_pred_gbdt =model_gbdt.predict(test_data.values)
with open('rank/regssion_0.6623.txt','w') as fw:
    fw.writelines('\n'.join([str(y) for y in y_pred_gbdt]))

